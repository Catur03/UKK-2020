<?php 
	
	$idTransaksi = $_GET['idTransaksi'];

	include "../config/koneksi.php";
	include "../config/function.php";
	$sql = "SELECT * FROM transaksi left join pesanan on pesanan.idPesanan =transaksi.idPesanan left join pelanggan on pesanan.idPelanggan = pelanggan.idPelanggan left join menu on pesanan.idMenu = menu.idMenu WHERE idTransaksi='$idTransaksi' ";
	$query = mysqli_query($koneksi,$sql);
	$cek = mysqli_num_rows($query);

	if ($cek >0 ) {
		$data =mysqli_fetch_array($query);
	}else{
		?>
			<script type="text/javascript">
				window.location.href="index.php?p=transaksi";
			</script>
		<?php
	}

 ?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Cetak Struk</title>
	<style type="text/css">
		body {
			font-family: monospace;
		}
		.cetak{
			width: 40%;
			height: auto;
			border: 1px solid #000;
			padding: 20px;

		}
	</style>
</head>
<body style="margin: 0 auto">
	<center>
		<div class="cetak" >
			<h2 style="margin: 0;">E-KASIR</h2>
			<span><?= date('d-m-Y') ."," . date('H:i:s')?></span>
			<br>
			<table style="float: none;" width="100%%" border="0" cellpadding="10">
				<tr>
					<td colspan="5"> Nama : <?= $data['namaPelanggan']; ?></td>
				</tr>
				<tr >
					<td style="border-bottom: 1px solid#999">   <?= $data['namaMenu']; ?> </td>
					<td style="border-bottom: 1px solid#999">   <?= rupiah($data['harga']); ?> </td>
					<td style="border-bottom: 1px solid#999"> X</td>
					<td style="border-bottom: 1px solid#999">   <?= $data['jumlah']; ?> </td>
					<td style="border-bottom: 1px solid#999"> =  <?= rupiah($data['total']); ?> </td>
				</tr>
				<tr>
					<td colspan="4">Uang bayar</td>
					<td> =  <?=rupiah($data ['bayar']); ?></td>
				</tr>
				<tr>
					<td colspan="4">Kembalian</td>
					<td> =  <?=rupiah($data ['kembalian']); ?></td>
				</tr>
				<tr>
					<td colspan="5" style="text-align: center;"> Terimakasih Atas Kunjungan Anda !</td>
				</tr>
		

	</table>
		</div>
	
</center>
	<script type="text/javascript">
		window.print()
	</script>
</body>
</html>