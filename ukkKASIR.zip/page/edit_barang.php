<?php 
	@$idMenu = $_GET['idMenu'];
	if (empty($idMenu)) {
		?>
		<script type="text/javascript">
			window.location.href="?p=list_barang";
		</script>
		<?php
	}
	$sql = "SELECT * FROM menu WHERE idMenu='$idMenu'";
	$query = mysqli_query($koneksi, $sql);
	$cek = mysqli_num_rows($query);
	if ($cek > 0) {
		$data = mysqli_fetch_array($query);
	}else{
		$data = NULL;
	}
	
 ?>

<div class="row">
	<h2>edit menu</h2>
	<div class="col-lg-6">
		<form action="" method="post" class="form">
			<div class="form-group">
				<label>Nama Menu</label>
				<input type="text" name="namaMenu" class="form-control" placeholder="masukan nama menu" value="<?= $data['namaMenu'] ?>">
			</div>
			<div class="form-group">
				<label>harga</label>
				<input type="number" name="harga" class="form-control" value="<?= $data ['harga'] ?>">
			</div>
			<div class="form-group">
				<input type="submit" name="simpan" value="Simpan" class="btn btn-md  btn-primary">
				<a href="?p=list_barang" class="btn btn-md btn-default">Kembali</a>
			</div>
		</form>
		<?php 
		if (isset($_POST['simpan'])) {
		 	$namaMenu = $_POST['namaMenu'];
		 	$harga = $_POST['harga'];
		 	$sql_update = "UPDATE menu SET namaMenu= '$namaMenu',
		 		harga = '$harga' WHERE idMenu='$idMenu'";
		 $q = mysqli_query($koneksi,$sql_update);
		 if ($q) {
		 	?>
		 	<script type="text/javascript">
		 		window.location.href="?p=list_barang"
		 	</script>
		 	<?php
		 }else{
		 	?>
		 	<div class="alert alert-success">
		 		Gagal menyimpan
		 	</div>
		 	<?php
		 }
		 } ?>
	</div>
</div>