<div class="row">
	<h2>tambah menu</h2>
	<div class="col-lg-6">
		<form action="" method="post" class="form">
			<div class="form-group">
				<label>Nama Menu</label>
				<input type="text" name="namaMenu" class="form-control" placeholder="masukan nama menu">
			</div>
			<div class="form-group">
				<label>harga</label>
				<input type="number" name="harga" class="form-control">
			</div>
			<div class="form-group">
				<input type="submit" name="simpan" value="Simpan" class="btn btn-md  btn-primary">
				<a href="?p=list_barang" class="btn btn-md btn-default">Kembali</a>
			</div>
		</form>
		
		<?php
			if (isset($_POST['simpan'])) {
				$namaMenu = $_POST['namaMenu'];
				$harga = $_POST['harga']	;
				$sql = "INSERT INTO menu SET namaMenu = '$namaMenu',harga ='$harga'"; 
				$query = mysqli_query($koneksi,$sql);
				if ($query) {
					?>
					<div class="alert alert-success">Berhasil Menambah Menu
					</div>
					<?php
				}else{
					?>
					<div class="alert alert-danger">
						Gagal Menambah Menu.
					</div>
					<?php
				}
			}
		?>


	</div>
</div>