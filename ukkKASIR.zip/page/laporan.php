<?php 
	$hari_ini = date('Y-m-d');

 ?>


<div class="col-lg-8">
	<div class="panel panel-default">
		<div class="panel-heading">Data Tansaksi</div>
		<div class="panel-body">
			<form action="" method="get" class ="form-inline">
				<input type="hidden" name="p" value="laporan">
			<div class="form-group">
				<label>Tanggal awal</label><br>
				<input id="tgl_awal" type="date"	name="tglDari" class="form-control" value="<?= !empty($_GET['tglDari']) ? $_GET['tglDari'] : $hari_ini ?> " >
			</div>
			<div class="form-group">
				<label>Tanggal Sampai</label><br>
				<input id="tgl_sampai" type="date"	name="tglSampai" class="form-control" value="<?=!empty($_GET['tglSampai']) ? $_GET['tglSampai'] : $hari_ini ?>" >
			</div>
			<div class="form-group">
				<br>
				<input type="submit" name="cari" value="Filter" class="btn btn-sm btn-primary">
				<button type="button" id="cetak"  class="btn-sm btn-success">Cetak</a>
			</div>
		</form>
		<br>
		<table class="table table-bordered table-striped">
			<thead>
				<tr>
					<th>no</th>
					<th>Nama</th>
					<th>menu</th>
					<th>Jumlah</th>
					<th>tanggal</th>
					<th>total</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					$cari ="";
					@$tglDari =$_GET['tglDari'];
					@$tglSampai=$_GET['tglSampai'];
					if(!empty($tglDari)){
						$cari .="and date(transaksi.created_at) >='".$tglDari."'";
					}

					if(!empty($tglSampai)){
						$cari .="and date (transaksi.created_at) <='".$tglSampai."'";
					}

					if (empty($tglDari) && empty($tglSampai)) {
						$cari .= " and date(transaksi.created_at) >= '".$hari_ini."' and date( transaksi.created_at )>='".$hari_ini."'";
					}


					$sql = "SELECT *, transaksi.created_at as tgl FROM transaksi left join pesanan on pesanan.idPesanan =transaksi.idPesanan left join pelanggan on pesanan.idPelanggan = pelanggan.idPelanggan left join menu on pesanan.idMenu = menu.idMenu WHERE 1=1 $cari";

					$query = mysqli_query($koneksi, $sql);
					$cek = mysqli_num_rows($query);
					if ($cek > 0) {
						$no = 1;
						while($data = mysqli_fetch_array($query)){
							?>
							
							<tr>
								<td><?= $no++ ?></td>
								<td><?= $data['namaPelanggan'] ?></td>
								<td><?= $data['namaMenu'] ?></td>
								<td><?= $data ['jumlah'] ?></td>
								<td><?= $data ['tgl'] ?></td>
								<td><?= rupiah($data['total']) ?></td>
							</tr>
							
							<?php
						}
					}else{
						?>
							<tr>
								<td colspan="6">Tidak ada data</td>
							</tr>

						<?php
					}

				 ?>
			</tbody>
		</table>
		</div>
	</div>
</div>

<div class="col-lg-4">
	<div class="panel panel-success">
		<div class="panel panel-heading">Total hari ini
			<div class="panel-body">
				<h2>
				 <?php 
				 $tot = "SELECT sum(total) as jumlah FROM transaksi WHERE date(created_at) = '".$hari_ini."'";
				 $q = mysqli_query($koneksi,$tot);
				 $data = mysqli_fetch_array($q);
				 echo rupiah($data['jumlah']);
					 ?>
			 	</h2>
			</div>
		</div>
	</div>


<div class="panel panel-success">
		<div class="panel panel-heading">Total 28 hari terakhir
			<div class="panel-body">
				<h2>
					<?php 
					$tgl_awal = mktime(0, 0, 0,date("m"), date("d") -27, date("Y"));
					$tgl_awal = date('Y-m-d' , $tgl_awal);
					
				 $tot = "SELECT sum(total) as jumlah FROM transaksi WHERE date(created_at) >= ' " .$tgl_awal."' and date(created_at) <= '".$hari_ini."'  ";
				 $q = mysqli_query($koneksi,$tot);
				 $data = mysqli_fetch_array($q);
				 echo rupiah($data['jumlah']); ?>
				 	
				 </h2>
			</div>
		</div>
	</div>



	<div class="panel panel-success">
		<div class="panel panel-heading">Total Selama Ini
			<div class="panel-body">
				<h2>
					<?php 
				 $tot = "SELECT sum(total) as jumlah FROM transaksi";
				 $q = mysqli_query($koneksi,$tot);
				 $data = mysqli_fetch_array($q);
				 echo rupiah($data['jumlah']); ?>
				</h2>
			</div>
		</div>
	</div>
</div>



	