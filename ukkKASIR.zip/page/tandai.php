<?php 
include "../config/koneksi.php";
$idPesanan = $_GET['idPesanan'];
if (empty($idPesanan)) {
	header('location:../index.php?p=pesan');
		
}

	$sql =" UPDATE pesanan SET status ='1' WHERE idPesanan='$idPesanan'"  ;
	$query = mysqli_query($koneksi, $sql);
	if ($query) {
	 	?>
			<script type="text/javascript">
				window.location.href="../index.php?p=pesan";				
			</script>
	 	<?php
	 } else {
	 	?>
	 		<script type="text/javascript">
	 			alert('Gagal mengubah status');
	 			window.location.href="../index.php?p=pesan";
	 		</script>	
	 	<?php
	 }

 ?>