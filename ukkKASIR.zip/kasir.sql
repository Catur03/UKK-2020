-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 12, 2020 at 03:10 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.1.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kasir`
--

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `idMenu` int(11) NOT NULL,
  `namaMenu` varchar(199) NOT NULL,
  `harga` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`idMenu`, `namaMenu`, `harga`, `created_at`, `updated_at`) VALUES
(1, 'Soto ayam', 5000, '2020-02-08 13:26:44', '2020-02-08 13:26:44'),
(2, 'es degan', 2000, '2020-02-09 13:56:02', '2020-02-09 13:56:02'),
(3, 'geprek', 7000, '2020-02-09 13:56:10', '2020-02-09 13:56:10'),
(4, 'kopi', 2000, '2020-02-09 13:56:17', '2020-02-09 13:56:17'),
(5, 'sate', 10000, '2020-02-09 13:56:26', '2020-02-09 13:56:26');

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `idPelanggan` varchar(6) NOT NULL,
  `namaPelanggan` varchar(100) NOT NULL,
  `jenisKelamin` enum('L','P') NOT NULL,
  `noHp` varchar(13) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`idPelanggan`, `namaPelanggan`, `jenisKelamin`, `noHp`, `alamat`) VALUES
('PLG001', 'catur', 'L', '12345', 'ponorogo'),
('PLG002', 'zen', 'P', '123456', 'jenangan'),
('PLG003', 'ryu', 'L', '123', 'tanjungsari'),
('PLG004', 'laporan', 'L', '123', 'ase'),
('PLG005', 'cek', 'L', '123', 'total'),
('PLG006', 'rupiah', 'L', '09876', 'ponorogo');

-- --------------------------------------------------------

--
-- Table structure for table `pesanan`
--

CREATE TABLE `pesanan` (
  `idPesanan` int(11) NOT NULL,
  `idMenu` int(11) NOT NULL,
  `idPelanggan` varchar(6) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `idUser` int(11) NOT NULL,
  `status` enum('0','1','2') NOT NULL,
  `tanggalPesanan` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pesanan`
--

INSERT INTO `pesanan` (`idPesanan`, `idMenu`, `idPelanggan`, `jumlah`, `idUser`, `status`, `tanggalPesanan`) VALUES
(13, 3, 'PLG001', 1, 1, '2', '2020-02-09 13:58:35'),
(14, 2, 'PLG002', 2, 1, '2', '2020-02-09 13:58:57'),
(15, 2, 'PLG003', 1, 1, '2', '2020-02-09 14:02:09'),
(16, 4, 'PLG004', 2, 3, '2', '2020-02-10 15:16:03'),
(17, 5, 'PLG005', 2, 3, '2', '2020-02-11 12:56:01'),
(18, 1, 'PLG006', 2, 1, '2', '2020-02-12 12:46:05');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `idTransaksi` varchar(6) NOT NULL,
  `idPesanan` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `bayar` int(11) NOT NULL,
  `kembalian` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`idTransaksi`, `idPesanan`, `total`, `bayar`, `kembalian`, `created_at`) VALUES
('TRX001', 13, 7000, 7000, 0, '2020-02-09 13:59:29'),
('TRX002', 14, 4000, 7000, 3000, '2020-02-09 14:00:38'),
('TRX003', 15, 2000, 10000, 8000, '2020-02-09 14:02:20'),
('TRX004', 16, 4000, 5000, 1000, '2020-02-10 15:31:03'),
('TRX005', 17, 20000, 20000, 0, '2020-02-11 12:56:17'),
('TRX006', 18, 10000, 20000, 10000, '2020-02-12 12:46:32');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `idUser` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `level` enum('admin','kasir','waiter','pemilik') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`idUser`, `username`, `password`, `level`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin'),
(2, 'kasir', 'c7911af3adbd12a035b289556d96470a', 'kasir'),
(3, 'waiter', 'f64cff138020a2060a9817272f563b3c', 'waiter'),
(4, 'pemilik', '58399557dae3c60e23c78606771dfa3d', 'pemilik');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`idMenu`);

--
-- Indexes for table `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`idPesanan`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`idTransaksi`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`idUser`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `idMenu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `pesanan`
--
ALTER TABLE `pesanan`
  MODIFY `idPesanan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `idUser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
