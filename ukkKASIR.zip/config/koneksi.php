<?php 
	$koneksi = mysqli_connect("localhost","root", "","kasir");
	if(mysqli_connect_errno()){
		echo "Koneksi Error :" . mysqli_connect_error();
	}
 ?>